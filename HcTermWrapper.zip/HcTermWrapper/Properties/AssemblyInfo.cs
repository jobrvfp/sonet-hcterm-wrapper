using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HcTermWrapper")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HcTermWrapper")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(true)]
[assembly: Guid("A1A0B6C3-7F4A-4B2E-9F11-DEF123456789")]
