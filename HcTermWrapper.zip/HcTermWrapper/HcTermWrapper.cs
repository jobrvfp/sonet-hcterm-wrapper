using System;
using System.Runtime.InteropServices;
using System.Text;

namespace HcTermWrapper
{
    [ComVisible(true)]
    [Guid("A1A0B6C3-7F4A-4B2E-9F11-DEF123456789")]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    public class HcTermCom
    {
        [DllImport("hcterm.dll")]
        private static extern int hcInit();

        [DllImport("hcterm.dll")]
        private static extern int hcOpen(string device);

        [DllImport("hcterm.dll")]
        private static extern int hcSale(int amount, string currency);

        [DllImport("hcterm.dll")]
        private static extern int hcGetResult(StringBuilder buffer, int length);

        public int Init() => hcInit();
        public int OpenTcp(string ip, int port) => hcOpen($"TCP:{ip}:{port}");
        public int Sale(int amount, string currency) => hcSale(amount, currency);
        public string GetResult()
        {
            var buf = new StringBuilder(1024);
            hcGetResult(buf, buf.Capacity);
            return buf.ToString();
        }
        public int Close() => hcOpen("CLOSE");
    }
}
