# HcTermWrapper (.NET COM Wrapper for hcterm.dll)

## 💾 Build & Register
1. Skopíruj `hcterm.dll` do koreňového priečinka
2. Spusti `build-and-register.bat` ako správca

## 🧪 Použitie vo Visual FoxPro
```foxpro
oTerm = CREATEOBJECT("HcTermWrapper.HcTermCom")
? oTerm.Init()
? oTerm.OpenTcp("192.168.0.100", 5555)
? oTerm.Sale(1000, "EUR")
? ? oTerm.GetResult()
? oTerm.Close()
```
